#!/bin/bash
set -euo pipefail

echo "=== Building pallet-verification-ui ==="

# Re-run npm install with workspaces now that ALL source files are present
echo "--- Installing build dependencies (full) ---"
cd /app
npm install --legacy-peer-deps --ignore-scripts

# Build the React UI from ui/ directory (vite.config.js sets outDir=../app)
echo "--- Building React UI ---"
cd /app/ui
/app/node_modules/.bin/vite build

# Build CAP backend for production (reads /app/app/ as static folder)
echo "--- Building CAP backend ---"
cd /app
/app/node_modules/.bin/cds build --production

OUTPUT_DIR="${OUTPUT_PATH:-/outputs}"
echo "--- Copying build output to ${OUTPUT_DIR} ---"

# Copy gen/srv contents (srv/, package.json etc.) to /outputs
cp -r /app/gen/srv/. "${OUTPUT_DIR}/"

# Add a server.js entry point (required by the distroless runtime CMD ["server.js"])
cat > "${OUTPUT_DIR}/server.js" << 'SERVERJS'
"use strict";
// Standard CAP server entry point for distroless deployment (node server.js)
const cds = require("@sap/cds");
module.exports = cds.server;
// Auto-start when this file is the main entry point
if (require.main === module) {
  cds.server().catch(function(e){ console.error(e); process.exit(1); });
}
SERVERJS

# Copy React static build to /outputs/app/
mkdir -p "${OUTPUT_DIR}/app"
if [ -d /app/app ] && [ "$(ls -A /app/app 2>/dev/null)" ]; then
  cp -r /app/app/. "${OUTPUT_DIR}/app/"
fi

# CRITICAL: Install production node_modules in /outputs.
# The runtime image is distroless - no npm/shell - it ONLY runs /outputs as /app.
# node_modules MUST be in /outputs for the server to start.
echo "--- Installing production node_modules in ${OUTPUT_DIR} ---"
cd "${OUTPUT_DIR}"
npm install --omit=dev --legacy-peer-deps --ignore-scripts

echo "=== Build complete ==="
